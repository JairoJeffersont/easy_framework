<?php

namespace App\Controllers;

use App\Core\Response;

//EXAMPLE CONTROLLER
class HomeController {
    public function index() {
        return Response::success('Working API');
    }
}
